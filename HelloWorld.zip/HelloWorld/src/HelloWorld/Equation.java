/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HelloWorld;

/**
 *
 * @author Rabin Koirala
 * @date 09/13/2021
 */
public class Equation {
    public static void main(String[] args) {
        // A simple java program to solve some equations 
       
       int add = 1+1;
       int multiply = 2*2;
       double divide = 3/2;
       int remain = 4%2;
       double solve1 =30+11*2/5%4;
       double solve2=30+11*2/5.0%4 ;

        System.out.println("Add : 1+1 = "+ add );
        System.out.println("Multiply : 2*2 = "+ multiply );
        System.out.println("Divide : 3/2 = "+ divide );
        System.out.println("Remainder : 4%2 = "+ remain );
        System.out.println("Solve =30+11*2/5%4 = "+ solve1 );
        System.out.println("Solve =30+11*2/5.0%4 = "+ solve2 );
            
    }
    
}
